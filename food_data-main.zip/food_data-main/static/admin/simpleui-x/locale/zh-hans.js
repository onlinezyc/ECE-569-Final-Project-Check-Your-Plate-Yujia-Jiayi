var Lanuages = {
    "Refresh": "刷新",
    "Close current": "关闭当前",
    "Close other": "关闭其他",
    "Close all": "全部关闭",
    "Open in a new page": "新标签打开",
    "Change theme": "改变主题",
    "Default": "默认",
    "Servers": "服务器",
    "Application information": "应用信息",
    "Home page": "主页",
    "Report issue": "报告问题",

    "Select": "选择",
    "Selected": "已选择",

    "Purple": "紫色",
    "Gray": "灰色",
    "Dark green": "墨绿",
    "Orange": "橙色",
    "Black": "黑色",
    "Green": "绿色",
    "Light": "淡雅",


    "Number": "编号",
    "Theme name": "主题名",
    "Action": "操作",

    "ConfirmYes": "确定",
    "ConfirmNo": "取消",
    "Tips": "提示",
    "Are you sure you want them all closed": "你确定要全部关闭吗？",

    "to": "至",
    "Quick navigation": "快捷操作",
    "Go back": '返回',

    'Set font size': '设置字体大小',
    'Reset': '重置',
    'Are you sure you want to delete the selected?': '你确定要删除选中的吗？',
    "Please select at least one option!": "请选中至少一个选项！",
    "Please enter your username or password!": "请输入您的用户名或密码！"
}